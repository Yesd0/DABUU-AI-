import { useState } from 'react';
import {
  Activity,
  Dumbbell,
  UserCheck,
  Apple,
  Maximize2,
  X,
  CheckCircle2,
} from 'lucide-react';
import { facilitiesData, galleryData, GymConfig } from '../data/gymData';
import { GymImage } from './GymImage';

interface FacilitiesSectionProps {
  config: GymConfig;
}

export function FacilitiesSection({ config }: FacilitiesSectionProps) {
  const [activeImage, setActiveImage] = useState<(typeof galleryData)[0] | null>(null);

  const getFacilityIcon = (iconType: string) => {
    switch (iconType) {
      case 'cardio':
        return <Activity className="w-6 h-6 text-red-500" />;
      case 'weights':
        return <Dumbbell className="w-6 h-6 text-red-500" />;
      case 'personal':
        return <UserCheck className="w-6 h-6 text-red-500" />;
      case 'diet':
        return <Apple className="w-6 h-6 text-red-500" />;
      default:
        return <Dumbbell className="w-6 h-6 text-red-500" />;
    }
  };

  return (
    <section id="facilities" className="py-20 bg-[#08090c] relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-20">
        {/* Sub-Part A: 4 Core Facilities */}
        <div>
          <div className="text-center max-w-3xl mx-auto mb-14 space-y-4">
            <span className="text-xs font-bold tracking-widest uppercase font-heading text-red-500 border border-red-500/20 px-3 py-1 rounded bg-red-950/20">
              WORLD-CLASS INFRASTRUCTURE
            </span>
            <h2 className="font-heading text-3xl sm:text-4xl md:text-5xl font-black uppercase text-white tracking-tight">
              Facilities & Amenities
            </h2>
            <p className="text-base sm:text-lg text-neutral-300">
              Built for performance. Clean. Sanitized daily. Everything you need under one roof in {config.city}.
            </p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {facilitiesData.map((facility) => (
              <div
                key={facility.id}
                className="bg-neutral-900/90 border border-neutral-800 rounded-2xl p-6 hover:border-red-600/60 transition-all duration-300 hover:-translate-y-1 group"
              >
                <div className="w-14 h-14 rounded-xl bg-neutral-950 border border-neutral-800 flex items-center justify-center mb-5 group-hover:border-red-500/40 group-hover:bg-red-950/20 transition-colors">
                  {getFacilityIcon(facility.icon)}
                </div>

                <h3 className="font-heading text-xl font-bold uppercase text-white tracking-wide mb-2">
                  {facility.name}
                </h3>
                <p className="text-sm text-neutral-400 mb-4 leading-relaxed">
                  {facility.shortDesc}
                </p>

                <div className="pt-3 border-t border-neutral-800 space-y-2">
                  {facility.features.map((item, idx) => (
                    <div key={idx} className="flex items-center gap-2 text-xs text-neutral-300">
                      <CheckCircle2 className="w-3.5 h-3.5 text-red-400 shrink-0" />
                      <span>{item}</span>
                    </div>
                  ))}
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Sub-Part B: Photo Grid of 6 Images */}
        <div className="pt-4">
          <div className="flex flex-col md:flex-row md:items-end justify-between mb-10 gap-4">
            <div>
              <span className="text-xs font-bold tracking-widest uppercase font-heading text-red-500">
                VISUAL TOUR
              </span>
              <h3 className="font-heading text-2xl sm:text-3xl md:text-4xl font-black uppercase text-white tracking-tight mt-1">
                Gym Gallery
              </h3>
              <p className="text-sm sm:text-base text-neutral-400 mt-1">
                Step inside {config.name} {config.edition}. High adrenaline, spotless hygiene.
              </p>
            </div>
            <span className="text-xs text-neutral-400 font-mono tracking-wider">
              TAP TO EXPAND PHOTO
            </span>
          </div>

          {/* Grid of 6 Images */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {galleryData.map((item, index) => (
              <div
                key={item.id}
                onClick={() => setActiveImage(item)}
                className="group relative cursor-pointer rounded-xl overflow-hidden border border-neutral-800 bg-neutral-900 aspect-[4/3] focus:outline-none focus-visible:ring-2 focus-visible:ring-red-500"
                tabIndex={0}
                onKeyDown={(e) => {
                  if (e.key === 'Enter' || e.key === ' ') {
                    setActiveImage(item);
                  }
                }}
              >
                <GymImage
                  src={item.imageUrl}
                  alt={item.title}
                  category={item.category}
                  className="w-full h-full"
                />

                {/* Scrim Overlay */}
                <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-black/20 to-transparent opacity-80 group-hover:opacity-95 transition-opacity duration-300 pointer-events-none" />

                {/* Category kicker */}
                <div className="absolute top-3 left-3">
                  <span className="text-[11px] font-bold tracking-wider font-heading uppercase px-2 py-0.5 rounded bg-black/60 backdrop-blur-md text-red-400 border border-neutral-700/80">
                    {item.category}
                  </span>
                </div>

                {/* Bottom Title & Expand Indicator */}
                <div className="absolute bottom-4 left-4 right-4 flex items-center justify-between pointer-events-none">
                  <div>
                    <span className="text-xs text-neutral-400 block font-mono">0{index + 1}</span>
                    <h4 className="font-heading text-base font-bold text-white tracking-wide leading-tight">
                      {item.title}
                    </h4>
                  </div>
                  <div className="w-8 h-8 rounded-full bg-red-600/80 text-white flex items-center justify-center group-hover:scale-110 transition-transform">
                    <Maximize2 className="w-4 h-4" />
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Lightbox Modal */}
      {activeImage && (
        <div
          className="fixed inset-0 z-50 bg-black/95 backdrop-blur-md flex items-center justify-center p-4"
          onClick={() => setActiveImage(null)}
        >
          <div
            className="relative max-w-4xl w-full bg-neutral-900 border border-neutral-800 rounded-2xl overflow-hidden shadow-2xl"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-center justify-between p-4 border-b border-neutral-800">
              <div>
                <span className="text-xs font-bold text-red-500 uppercase tracking-widest font-heading">
                  {activeImage.category}
                </span>
                <h4 className="font-heading text-xl font-bold text-white uppercase">
                  {activeImage.title}
                </h4>
              </div>
              <button
                onClick={() => setActiveImage(null)}
                className="p-2 rounded-lg bg-neutral-800 text-neutral-300 hover:text-white hover:bg-neutral-700 transition-colors"
                aria-label="Close image modal"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="max-h-[70vh] overflow-hidden bg-black flex items-center justify-center">
              <GymImage
                src={activeImage.imageUrl}
                alt={activeImage.title}
                category={activeImage.category}
                className="w-full max-h-[70vh] object-contain"
              />
            </div>

            <div className="p-4 bg-neutral-950 flex items-center justify-between text-xs text-neutral-400 border-t border-neutral-800">
              <span>RJ Fitness Hub {config.edition} · {config.city}</span>
              <button
                onClick={() => setActiveImage(null)}
                className="text-red-400 hover:text-red-300 font-semibold uppercase font-heading tracking-wider"
              >
                Close (ESC)
              </button>
            </div>
          </div>
        </div>
      )}
    </section>
  );
}
