import { useState } from 'react';
import { Dumbbell } from 'lucide-react';

interface GymImageProps {
  src: string;
  alt: string;
  className?: string;
  category?: string;
}

export function GymImage({ src, alt, className = '', category }: GymImageProps) {
  const [hasError, setHasError] = useState(false);
  const [isLoaded, setIsLoaded] = useState(false);

  if (hasError) {
    return (
      <div
        className={`relative flex flex-col items-center justify-center bg-gradient-to-br from-neutral-900 via-neutral-950 to-red-950/40 p-6 text-center border border-neutral-800 ${className}`}
      >
        <div className="w-12 h-12 rounded-lg bg-red-600/20 border border-red-500/30 flex items-center justify-center text-red-400 mb-2">
          <Dumbbell className="w-6 h-6" />
        </div>
        <span className="text-sm font-semibold tracking-wide text-neutral-200">{alt}</span>
        {category && (
          <span className="text-xs text-red-400 font-medium tracking-wider uppercase mt-1">
            {category}
          </span>
        )}
      </div>
    );
  }

  return (
    <div className={`relative overflow-hidden bg-neutral-900 ${className}`}>
      {!isLoaded && (
        <div className="absolute inset-0 bg-neutral-900 animate-pulse flex items-center justify-center">
          <Dumbbell className="w-6 h-6 text-neutral-700 animate-bounce" />
        </div>
      )}
      <img
        src={src}
        alt={alt}
        referrerPolicy="no-referrer"
        onLoad={() => setIsLoaded(true)}
        onError={() => setHasError(true)}
        className={`w-full h-full object-cover transition-transform duration-500 hover:scale-105 ${
          isLoaded ? 'opacity-100' : 'opacity-0'
        }`}
      />
    </div>
  );
}
