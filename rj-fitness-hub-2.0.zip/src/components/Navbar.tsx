import { useState } from 'react';
import { Menu, X, SlidersHorizontal, MessageSquare } from 'lucide-react';
import { GymConfig, buildWhatsAppLink } from '../data/gymData';

interface NavbarProps {
  config: GymConfig;
  onOpenCustomizer: () => void;
}

export function Navbar({ config, onOpenCustomizer }: NavbarProps) {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const trialWhatsAppUrl = buildWhatsAppLink(
    config.whatsappRaw,
    `Hi ${config.name} ${config.edition}! I would like to book a free trial workout session at your ${config.city} gym.`
  );

  return (
    <header className="sticky top-0 z-40 bg-[#08090c]/90 backdrop-blur-md border-b border-neutral-800/80">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between gap-8 h-20">
          {/* Zone 1: Brand Wordmark (Single text element in athletic display style) */}
          <a
            href="#hero"
            className="flex items-center gap-2 group whitespace-nowrap shrink-0 text-decoration-none"
          >
            <div className="w-10 h-10 rounded bg-red-600 flex items-center justify-center font-heading font-black text-xl text-white tracking-tighter shadow-md shadow-red-600/30 group-hover:bg-red-500 transition-colors">
              RJ
            </div>
            <div className="flex flex-col">
              <span className="font-heading text-xl md:text-2xl font-black tracking-wide text-white leading-none">
                {config.name.toUpperCase()}
                <span className="text-red-500 ml-1.5">{config.edition}</span>
              </span>
            </div>
          </a>

          {/* Zone 2: Nav Links (Clean, single-line text links with subtle hover underlines) */}
          <nav className="hidden md:flex items-center gap-8 text-sm font-medium text-neutral-300">
            <a
              href="#hero"
              className="hover:text-white hover:border-b-2 hover:border-red-500 pb-1 transition-all whitespace-nowrap shrink-0"
            >
              About
            </a>
            <a
              href="#plans"
              className="hover:text-white hover:border-b-2 hover:border-red-500 pb-1 transition-all whitespace-nowrap shrink-0"
            >
              Plans & Prices
            </a>
            <a
              href="#facilities"
              className="hover:text-white hover:border-b-2 hover:border-red-500 pb-1 transition-all whitespace-nowrap shrink-0"
            >
              Facilities & Gallery
            </a>
            <a
              href="#contact"
              className="hover:text-white hover:border-b-2 hover:border-red-500 pb-1 transition-all whitespace-nowrap shrink-0"
            >
              Contact
            </a>
          </nav>

          {/* Zone 3: 1 Primary Action + Quick Customizer */}
          <div className="flex items-center gap-3 shrink-0">
            <button
              onClick={onOpenCustomizer}
              title="Customize City, Prices & Contact"
              className="hidden sm:flex items-center gap-1.5 px-3 py-2 text-xs font-semibold text-neutral-300 bg-neutral-900 hover:bg-neutral-800 border border-neutral-700/80 rounded transition-colors whitespace-nowrap shrink-0"
            >
              <SlidersHorizontal className="w-3.5 h-3.5 text-red-400" />
              <span>Edit Details ({config.city})</span>
            </button>

            <a
              href={trialWhatsAppUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center gap-2 px-4 py-2.5 text-xs sm:text-sm font-bold tracking-wide uppercase font-heading bg-red-600 hover:bg-red-500 active:scale-95 text-white rounded transition-all shadow-md shadow-red-600/30 whitespace-nowrap shrink-0"
            >
              <MessageSquare className="w-4 h-4 fill-white/20" />
              <span>Book Free Trial</span>
            </a>

            {/* Mobile menu toggle */}
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="md:hidden p-2 text-neutral-400 hover:text-white focus:outline-none"
              aria-label="Toggle navigation menu"
            >
              {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Drawer Menu */}
      {mobileMenuOpen && (
        <div className="md:hidden border-t border-neutral-800 bg-[#0d1017] px-4 pt-4 pb-6 space-y-3">
          <nav className="flex flex-col space-y-3">
            <a
              href="#hero"
              onClick={() => setMobileMenuOpen(false)}
              className="px-3 py-2 text-sm font-medium text-neutral-200 hover:bg-neutral-800 rounded transition-colors"
            >
              About Hub
            </a>
            <a
              href="#plans"
              onClick={() => setMobileMenuOpen(false)}
              className="px-3 py-2 text-sm font-medium text-neutral-200 hover:bg-neutral-800 rounded transition-colors"
            >
              Plans & Prices
            </a>
            <a
              href="#facilities"
              onClick={() => setMobileMenuOpen(false)}
              className="px-3 py-2 text-sm font-medium text-neutral-200 hover:bg-neutral-800 rounded transition-colors"
            >
              Facilities & Gallery
            </a>
            <a
              href="#contact"
              onClick={() => setMobileMenuOpen(false)}
              className="px-3 py-2 text-sm font-medium text-neutral-200 hover:bg-neutral-800 rounded transition-colors"
            >
              Contact & Timings
            </a>
          </nav>
          <div className="pt-2 border-t border-neutral-800 flex items-center justify-between">
            <button
              onClick={() => {
                setMobileMenuOpen(false);
                onOpenCustomizer();
              }}
              className="w-full flex items-center justify-center gap-2 px-3 py-2 text-xs font-semibold text-neutral-300 bg-neutral-900 border border-neutral-700 rounded"
            >
              <SlidersHorizontal className="w-3.5 h-3.5 text-red-400" />
              <span>Customize City [{config.city}] & Rates</span>
            </button>
          </div>
        </div>
      )}
    </header>
  );
}
