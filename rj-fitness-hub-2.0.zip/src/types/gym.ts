export interface Plan {
  id: string;
  name: string;
  period: string;
  price: number;
  highlighted?: boolean;
  savingsNote?: string;
  features: string[];
}

export interface Facility {
  id: string;
  name: string;
  shortDesc: string;
  icon: 'cardio' | 'weights' | 'personal' | 'diet';
  features: string[];
}

export interface GalleryItem {
  id: string;
  title: string;
  category: string;
  imageUrl: string;
  aspect: string;
}

export interface GymConfig {
  name: string;
  edition: string;
  city: string;
  phone: string;
  phoneRaw: string;
  whatsapp: string;
  whatsappRaw: string;
  instagramHandle: string;
  instagramUrl: string;
  address: string;
  timings: string;
  weekdayTimings: string;
  sundayTimings: string;
  googleMapsQuery: string;
  plans: Plan[];
}
