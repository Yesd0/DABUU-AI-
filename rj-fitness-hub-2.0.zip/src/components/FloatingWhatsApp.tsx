import { MessageSquare } from 'lucide-react';
import { GymConfig, buildWhatsAppLink } from '../data/gymData';

interface FloatingWhatsAppProps {
  config: GymConfig;
}

export function FloatingWhatsApp({ config }: FloatingWhatsAppProps) {
  const url = buildWhatsAppLink(
    config.whatsappRaw,
    `Hi ${config.name} ${config.edition}! I would like more information about joining your gym in ${config.city}.`
  );

  return (
    <aside
      aria-label="Floating WhatsApp Contact"
      className="fixed bottom-5 right-5 z-40 flex items-center gap-2"
    >
      <a
        href={url}
        target="_blank"
        rel="noopener noreferrer"
        aria-label="Chat on WhatsApp with RJ Fitness Hub 2.0"
        className="group flex items-center gap-2.5 px-4 py-3 bg-[#25D366] hover:bg-[#20ba59] active:scale-95 text-white font-bold text-sm rounded-full shadow-xl shadow-black/50 transition-all duration-200 border border-emerald-400/40"
      >
        <div className="relative">
          <MessageSquare className="w-5 h-5 fill-white" />
        </div>
        <span className="font-heading uppercase tracking-wider text-xs sm:text-sm whitespace-nowrap">
          WhatsApp Chat
        </span>
      </a>
    </aside>
  );
}
