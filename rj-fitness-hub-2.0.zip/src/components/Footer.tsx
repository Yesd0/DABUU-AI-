import { Instagram, MapPin, Phone, MessageSquare, ChevronUp } from 'lucide-react';
import { GymConfig, buildWhatsAppLink } from '../data/gymData';

interface FooterProps {
  config: GymConfig;
  onOpenCustomizer: () => void;
}

export function Footer({ config, onOpenCustomizer }: FooterProps) {
  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <footer className="bg-[#050608] border-t border-neutral-800 text-neutral-400 py-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-10">
        <div className="flex flex-col md:flex-row items-center justify-between gap-6 pb-8 border-b border-neutral-850">
          {/* Brand lockup */}
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded bg-red-600 flex items-center justify-center font-heading font-black text-xl text-white">
              RJ
            </div>
            <div>
              <span className="font-heading text-xl font-black text-white tracking-wide block leading-none">
                {config.name.toUpperCase()} <span className="text-red-500">{config.edition}</span>
              </span>
              <span className="text-xs text-neutral-400">
                {config.city}&apos;s premier fitness destination
              </span>
            </div>
          </div>

          {/* Quick Links */}
          <div className="flex flex-wrap items-center justify-center gap-6 text-xs sm:text-sm font-medium">
            <a href="#hero" className="hover:text-white transition-colors">
              About
            </a>
            <a href="#plans" className="hover:text-white transition-colors">
              Plans & Prices
            </a>
            <a href="#facilities" className="hover:text-white transition-colors">
              Facilities & Gallery
            </a>
            <a href="#contact" className="hover:text-white transition-colors">
              Contact
            </a>
            <button
              onClick={onOpenCustomizer}
              className="text-red-400 hover:text-red-300 font-semibold transition-colors"
            >
              Configure Details
            </button>
          </div>

          {/* Back to top */}
          <button
            onClick={scrollToTop}
            className="flex items-center gap-2 text-xs font-bold font-heading uppercase text-neutral-400 hover:text-white transition-colors"
            aria-label="Back to top"
          >
            <span>Back to Top</span>
            <ChevronUp className="w-4 h-4" />
          </button>
        </div>

        {/* Footer bottom notice */}
        <div className="flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-neutral-400">
          <p>© RJ Fitness Hub 2.0</p>
          <div className="flex items-center gap-4">
            <span className="text-neutral-400">Sample design</span>
            <span aria-hidden="true">·</span>
            <a
              href={config.instagramUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="hover:text-white flex items-center gap-1 transition-colors"
            >
              <Instagram className="w-3.5 h-3.5 text-red-500" />
              <span>{config.instagramHandle}</span>
            </a>
          </div>
        </div>
      </div>
    </footer>
  );
}
