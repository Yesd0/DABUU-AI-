import { useState } from 'react';
import { X, Check, RotateCcw, MapPin } from 'lucide-react';
import { initialGymConfig } from '../data/gymData';
import { GymConfig, Plan } from '../types/gym';

interface CustomizerModalProps {
  isOpen: boolean;
  onClose: () => void;
  config: GymConfig;
  onSave: (newConfig: GymConfig) => void;
}

const cityPresets: Array<{
  city: string;
  address: string;
  timings: string;
  monthly: number;
  quarterly: number;
  yearly: number;
  phone: string;
  phoneRaw: string;
}> = [
  {
    city: 'Indore',
    address: '2nd Floor, Apex Business Park, Near C21 Mall, AB Road, Indore, Madhya Pradesh 452010',
    timings: 'Mon – Sat: 6:00 AM – 10:00 PM · Sun: 7:00 AM – 1:00 PM',
    monthly: 1499,
    quarterly: 3799,
    yearly: 11999,
    phone: '+91 98260 12345',
    phoneRaw: '919826012345',
  },
  {
    city: 'Pune',
    address: 'Survey No. 45, Baner High Street, Near Balewadi Phata, Pune, Maharashtra 411045',
    timings: 'Mon – Sat: 5:30 AM – 10:30 PM · Sun: 6:30 AM – 1:30 PM',
    monthly: 1799,
    quarterly: 4499,
    yearly: 13999,
    phone: '+91 98220 54321',
    phoneRaw: '919822054321',
  },
  {
    city: 'Bengaluru',
    address: '100 Feet Road, Indiranagar, 2nd Stage, Bengaluru, Karnataka 560038',
    timings: 'Mon – Sat: 6:00 AM – 10:30 PM · Sun: 7:00 AM – 2:00 PM',
    monthly: 1999,
    quarterly: 4999,
    yearly: 15999,
    phone: '+91 98450 78901',
    phoneRaw: '919845078901',
  },
  {
    city: 'Delhi NCR',
    address: 'Sector 29, Leisure Valley Road, Gurugram / Delhi NCR 122002',
    timings: 'Mon – Sat: 6:00 AM – 11:00 PM · Sun: 7:00 AM – 1:00 PM',
    monthly: 1899,
    quarterly: 4799,
    yearly: 14999,
    phone: '+91 98110 34567',
    phoneRaw: '919811034567',
  },
  {
    city: 'Jaipur',
    address: 'Tonk Road, Near Gaurav Tower, Malviya Nagar, Jaipur, Rajasthan 302017',
    timings: 'Mon – Sat: 6:00 AM – 10:00 PM · Sun: 7:00 AM – 12:30 PM',
    monthly: 1399,
    quarterly: 3499,
    yearly: 10999,
    phone: '+91 98290 67890',
    phoneRaw: '919829067890',
  },
];

export function CustomizerModal({ isOpen, onClose, config, onSave }: CustomizerModalProps) {
  const [city, setCity] = useState(config.city);
  const [address, setAddress] = useState(config.address);
  const [timings, setTimings] = useState(config.timings);
  const [phone, setPhone] = useState(config.phone);
  const [monthlyPrice, setMonthlyPrice] = useState(config.plans[0].price);
  const [quarterlyPrice, setQuarterlyPrice] = useState(config.plans[1].price);
  const [yearlyPrice, setYearlyPrice] = useState(config.plans[2].price);

  if (!isOpen) return null;

  const handleApplyPreset = (preset: (typeof cityPresets)[0]) => {
    setCity(preset.city);
    setAddress(preset.address);
    setTimings(preset.timings);
    setPhone(preset.phone);
    setMonthlyPrice(preset.monthly);
    setQuarterlyPrice(preset.quarterly);
    setYearlyPrice(preset.yearly);
  };

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    const rawNumber = phone.replace(/\D/g, '') || '919826012345';
    const updatedPlans = config.plans.map((p: Plan) => {
      if (p.id === 'monthly') return { ...p, price: Number(monthlyPrice) || 1499 };
      if (p.id === 'quarterly') return { ...p, price: Number(quarterlyPrice) || 3799 };
      if (p.id === 'yearly') return { ...p, price: Number(yearlyPrice) || 11999 };
      return p;
    });

    onSave({
      ...config,
      city: city.trim() || 'Indore',
      address: address.trim() || config.address,
      timings: timings.trim() || config.timings,
      phone: phone.trim() || config.phone,
      phoneRaw: rawNumber,
      whatsapp: phone.trim() || config.whatsapp,
      whatsappRaw: rawNumber,
      googleMapsQuery: encodeURIComponent(`${city} India`),
      plans: updatedPlans,
    });
    onClose();
  };

  const handleReset = () => {
    onSave(initialGymConfig);
    setCity(initialGymConfig.city);
    setAddress(initialGymConfig.address);
    setTimings(initialGymConfig.timings);
    setPhone(initialGymConfig.phone);
    setMonthlyPrice(initialGymConfig.plans[0].price);
    setQuarterlyPrice(initialGymConfig.plans[1].price);
    setYearlyPrice(initialGymConfig.plans[2].price);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-sm flex items-center justify-center p-4">
      <div
        className="relative max-w-xl w-full bg-[#0d1017] border border-neutral-800 rounded-2xl overflow-hidden shadow-2xl max-h-[90vh] flex flex-col"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="flex items-center justify-between p-5 border-b border-neutral-800 bg-[#090b0f]">
          <div>
            <h3 className="font-heading text-xl font-bold uppercase text-white tracking-wide">
              Customize Gym Template
            </h3>
            <p className="text-xs text-neutral-400 mt-0.5">
              Instantly replace prompt placeholders: [city], [price], [address], [timings], [number]
            </p>
          </div>
          <button
            onClick={onClose}
            className="p-2 rounded-lg text-neutral-400 hover:text-white hover:bg-neutral-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Form Body */}
        <form onSubmit={handleSave} className="p-6 space-y-6 overflow-y-auto">
          {/* Quick Presets */}
          <div>
            <label className="text-xs font-bold font-heading uppercase text-red-400 tracking-wider block mb-2">
              Select City Preset (One-Click)
            </label>
            <div className="flex flex-wrap gap-2">
              {cityPresets.map((preset) => (
                <button
                  type="button"
                  key={preset.city}
                  onClick={() => handleApplyPreset(preset)}
                  className={`px-3 py-1.5 text-xs font-semibold rounded-lg border transition-all ${
                    city.toLowerCase() === preset.city.toLowerCase()
                      ? 'bg-red-600 text-white border-red-500 shadow-sm'
                      : 'bg-neutral-900 text-neutral-300 border-neutral-800 hover:border-neutral-700'
                  }`}
                >
                  {preset.city}
                </button>
              ))}
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="text-xs font-semibold text-neutral-300 block mb-1.5">
                City [city]
              </label>
              <div className="relative">
                <MapPin className="w-4 h-4 text-neutral-500 absolute left-3 top-3" />
                <input
                  type="text"
                  value={city}
                  onChange={(e) => setCity(e.target.value)}
                  placeholder="e.g. Indore, Pune, Jaipur"
                  className="w-full pl-9 pr-3 py-2 text-sm rounded-lg bg-neutral-950 border border-neutral-800 text-white focus:outline-none focus:border-red-500"
                  required
                />
              </div>
            </div>

            <div>
              <label className="text-xs font-semibold text-neutral-300 block mb-1.5">
                WhatsApp & Phone [number]
              </label>
              <input
                type="text"
                value={phone}
                onChange={(e) => setPhone(e.target.value)}
                placeholder="+91 98260 12345"
                className="w-full px-3 py-2 text-sm rounded-lg bg-neutral-950 border border-neutral-800 text-white focus:outline-none focus:border-red-500"
                required
              />
            </div>
          </div>

          {/* Pricing inputs */}
          <div>
            <label className="text-xs font-bold font-heading uppercase text-neutral-300 tracking-wider block mb-2">
              Membership Prices ₹[price]
            </label>
            <div className="grid grid-cols-3 gap-3">
              <div>
                <span className="text-[11px] text-neutral-400 block mb-1">Monthly (₹)</span>
                <input
                  type="number"
                  value={monthlyPrice}
                  onChange={(e) => setMonthlyPrice(Number(e.target.value))}
                  className="w-full px-3 py-2 text-sm font-mono rounded-lg bg-neutral-950 border border-neutral-800 text-white focus:outline-none focus:border-red-500"
                  required
                />
              </div>
              <div>
                <span className="text-[11px] text-neutral-400 block mb-1">Quarterly (₹)</span>
                <input
                  type="number"
                  value={quarterlyPrice}
                  onChange={(e) => setQuarterlyPrice(Number(e.target.value))}
                  className="w-full px-3 py-2 text-sm font-mono rounded-lg bg-neutral-950 border border-neutral-800 text-white focus:outline-none focus:border-red-500"
                  required
                />
              </div>
              <div>
                <span className="text-[11px] text-neutral-400 block mb-1">Yearly (₹)</span>
                <input
                  type="number"
                  value={yearlyPrice}
                  onChange={(e) => setYearlyPrice(Number(e.target.value))}
                  className="w-full px-3 py-2 text-sm font-mono rounded-lg bg-neutral-950 border border-neutral-800 text-white focus:outline-none focus:border-red-500"
                  required
                />
              </div>
            </div>
          </div>

          {/* Address input */}
          <div>
            <label className="text-xs font-semibold text-neutral-300 block mb-1.5">
              Gym Address [address]
            </label>
            <textarea
              value={address}
              onChange={(e) => setAddress(e.target.value)}
              rows={2}
              className="w-full px-3 py-2 text-sm rounded-lg bg-neutral-950 border border-neutral-800 text-white focus:outline-none focus:border-red-500"
              required
            />
          </div>

          {/* Timings input */}
          <div>
            <label className="text-xs font-semibold text-neutral-300 block mb-1.5">
              Gym Timings [timings]
            </label>
            <input
              type="text"
              value={timings}
              onChange={(e) => setTimings(e.target.value)}
              className="w-full px-3 py-2 text-sm rounded-lg bg-neutral-950 border border-neutral-800 text-white focus:outline-none focus:border-red-500"
              required
            />
          </div>

          {/* Actions */}
          <div className="pt-2 flex items-center justify-between border-t border-neutral-800">
            <button
              type="button"
              onClick={handleReset}
              className="flex items-center gap-1.5 text-xs text-neutral-400 hover:text-white transition-colors"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              <span>Reset to Defaults</span>
            </button>

            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={onClose}
                className="px-4 py-2 text-xs font-semibold text-neutral-300 hover:text-white bg-neutral-900 rounded-lg transition-colors"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="px-5 py-2 text-xs font-bold uppercase font-heading tracking-wider bg-red-600 hover:bg-red-500 text-white rounded-lg flex items-center gap-1.5 transition-all shadow-md shadow-red-600/30"
              >
                <Check className="w-4 h-4" />
                <span>Apply Changes</span>
              </button>
            </div>
          </div>
        </form>
      </div>
    </div>
  );
}
