import { GymConfig, Facility, GalleryItem, Plan } from '../types/gym';
export type { GymConfig, Facility, GalleryItem, Plan };

export const initialGymConfig: GymConfig = {
  name: 'RJ Fitness Hub',
  edition: '2.0',
  city: 'Indore',
  phone: '+91 98260 12345',
  phoneRaw: '919826012345',
  whatsapp: '+91 98260 12345',
  whatsappRaw: '919826012345',
  instagramHandle: '@rj_fitness_2.0',
  instagramUrl: 'https://instagram.com/rj_fitness_2.0',
  address: '2nd Floor, Apex Business Park, Near C21 Mall, AB Road, Indore, Madhya Pradesh 452010',
  timings: 'Mon – Sat: 6:00 AM – 10:00 PM · Sun: 7:00 AM – 1:00 PM',
  weekdayTimings: 'Monday – Saturday: 6:00 AM – 10:00 PM',
  sundayTimings: 'Sunday: 7:00 AM – 1:00 PM',
  googleMapsQuery: 'Indore+Madhya+Pradesh+India',
  plans: [
    {
      id: 'monthly',
      name: 'Monthly',
      period: 'per month',
      price: 1499,
      highlighted: false,
      savingsNote: 'Flexible membership',
      features: [
        'Full gym floor access',
        'Locker & shower facilities',
        'Initial fitness assessment',
        'Certified floor trainer assistance',
        'Standard equipment usage',
      ],
    },
    {
      id: 'quarterly',
      name: 'Quarterly',
      period: 'for 3 months',
      price: 3799,
      highlighted: true,
      savingsNote: 'Save 15% · Most popular',
      features: [
        'All Monthly benefits',
        'Customized workout split plan',
        'Monthly body composition scan',
        'Nutrition guidelines review',
        '1 Free guest day pass',
      ],
    },
    {
      id: 'yearly',
      name: 'Yearly',
      period: 'for 12 months',
      price: 11999,
      highlighted: false,
      savingsNote: 'Save 33% · Best value',
      features: [
        'All Quarterly benefits',
        '2 Free Personal Training sessions',
        'Personalized nutrition chart',
        'Priority locker assignment',
        'Freeze membership up to 30 days',
      ],
    },
  ],
};

export const facilitiesData: Facility[] = [
  {
    id: 'cardio',
    name: 'Cardio Deck',
    shortDesc: 'High-calorie burn equipment with continuous heart-rate tracking.',
    icon: 'cardio',
    features: ['Commercial treadmills', 'Stair masters & ellipticals', 'Assault air bikes & rowers'],
  },
  {
    id: 'weights',
    name: 'Free Weights & Strength',
    shortDesc: 'Heavy-duty power racks, Olympic barbells, and dumbells up to 50kg.',
    icon: 'weights',
    features: ['Multi-grip power cages', 'Olympic competition plates', 'Plate-loaded isolation machines'],
  },
  {
    id: 'personal',
    name: 'Personal Training',
    shortDesc: 'Certified coaches dedicated to your form, progressive overload, and safety.',
    icon: 'personal',
    features: ['1-on-1 coach attention', 'Tailored goal tracking', 'Form correction & injury prevention'],
  },
  {
    id: 'diet',
    name: 'Diet Guidance',
    shortDesc: 'Science-backed macro planning and meal splits customized to Indian diets.',
    icon: 'diet',
    features: ['Custom macro calculations', 'Veg & non-veg meal plans', 'Pre & post-workout protocols'],
  },
];

export const galleryData: GalleryItem[] = [
  {
    id: 'img-1',
    title: 'Olympic Strength & Barbell Zone',
    category: 'Weights',
    imageUrl: 'https://images.unsplash.com/photo-1534438327276-14e5300c3a48?auto=format&fit=crop&w=1200&q=80',
    aspect: '4:3',
  },
  {
    id: 'img-2',
    title: 'High-Tech Endurance Cardio Row',
    category: 'Cardio',
    imageUrl: 'https://images.unsplash.com/photo-1540497077202-7c8a3999166f?auto=format&fit=crop&w=1200&q=80',
    aspect: '4:3',
  },
  {
    id: 'img-3',
    title: '1-on-1 Dedicated Coaching',
    category: 'Training',
    imageUrl: 'https://images.unsplash.com/photo-1571019614242-c5c5dee9f50b?auto=format&fit=crop&w=1200&q=80',
    aspect: '4:3',
  },
  {
    id: 'img-4',
    title: 'Functional Turf & Battle Ropes',
    category: 'Functional',
    imageUrl: 'https://images.unsplash.com/photo-1517838277536-f5f99be501cd?auto=format&fit=crop&w=1200&q=80',
    aspect: '4:3',
  },
  {
    id: 'img-5',
    title: 'Dumbbell Studio (2.5kg to 50kg)',
    category: 'Weights',
    imageUrl: 'https://images.unsplash.com/photo-1584735935682-2f2b69dff9d2?auto=format&fit=crop&w=1200&q=80',
    aspect: '4:3',
  },
  {
    id: 'img-6',
    title: 'Clean Changing & Locker Suites',
    category: 'Facility',
    imageUrl: 'https://images.unsplash.com/photo-1593079831268-3381b0db4a77?auto=format&fit=crop&w=1200&q=80',
    aspect: '4:3',
  },
];

export function buildWhatsAppLink(phoneRaw: string, message: string): string {
  const cleanPhone = phoneRaw.replace(/\D/g, '');
  const encodedText = encodeURIComponent(message);
  return `https://wa.me/${cleanPhone}?text=${encodedText}`;
}
