import { Check, MessageSquare, Sparkles, UserCheck } from 'lucide-react';
import { buildWhatsAppLink } from '../data/gymData';
import { GymConfig, Plan } from '../types/gym';

interface PlansSectionProps {
  config: GymConfig;
}

export function PlansSection({ config }: PlansSectionProps) {
  return (
    <section id="plans" className="py-20 bg-[#090b0f] border-t border-b border-neutral-800/80 relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-16 space-y-4">
          <div className="inline-flex items-center gap-2 text-xs font-bold tracking-widest uppercase font-heading text-red-500 border border-red-500/20 px-3 py-1 rounded bg-red-950/20">
            <Sparkles className="w-3.5 h-3.5" />
            <span>TRANSPARENT MEMBERSHIPS · NO HIDDEN CHARGES</span>
          </div>
          <h2 className="font-heading text-3xl sm:text-4xl md:text-5xl font-black uppercase text-white tracking-tight">
            Plans & Prices
          </h2>
          <p className="text-base sm:text-lg text-neutral-300">
            Choose your fitness commitment. Start strong in {config.city} today.
          </p>
        </div>

        {/* 3 Pricing Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 items-stretch">
          {config.plans.map((plan: Plan) => {
            const joinWhatsAppUrl = buildWhatsAppLink(
              config.whatsappRaw,
              `Hi ${config.name} ${config.edition}! I want to join the ${plan.name} Membership (₹${plan.price.toLocaleString('en-IN')}) at ${config.city}. Please share signup steps.`
            );

            return (
              <div
                key={plan.id}
                className={`relative rounded-2xl flex flex-col justify-between transition-all duration-300 p-8 ${
                  plan.highlighted
                    ? 'bg-gradient-to-b from-neutral-900 via-neutral-900 to-red-950/30 border-2 border-red-600 shadow-2xl glow-red md:-translate-y-2'
                    : 'bg-neutral-900/90 border border-neutral-800 hover:border-neutral-700'
                }`}
              >
                {/* Optional Highlight Tag */}
                {plan.savingsNote && (
                  <div className="mb-4">
                    <span
                      className={`text-xs font-bold uppercase tracking-wider font-heading px-2.5 py-1 rounded ${
                        plan.highlighted
                          ? 'bg-red-600 text-white'
                          : 'bg-neutral-800 text-neutral-300 border border-neutral-700'
                      }`}
                    >
                      {plan.savingsNote}
                    </span>
                  </div>
                )}

                <div>
                  <h3 className="font-heading text-2xl font-black uppercase tracking-wide text-white">
                    {plan.name}
                  </h3>
                  <div className="mt-4 flex items-baseline gap-1">
                    <span className="text-4xl sm:text-5xl font-black text-white font-mono tracking-tight">
                      ₹{plan.price.toLocaleString('en-IN')}
                    </span>
                    <span className="text-sm font-medium text-neutral-400">/{plan.period}</span>
                  </div>

                  <p className="text-xs text-neutral-400 mt-1 mb-6">Inclusive of all gym amenities & taxes.</p>

                  <div className="w-full h-px bg-neutral-800 mb-6" />

                  {/* Features list */}
                  <ul className="space-y-3.5 mb-8">
                    {plan.features.map((feature: string, idx: number) => (
                      <li key={idx} className="flex items-start gap-3 text-sm text-neutral-200">
                        <div
                          className={`w-5 h-5 rounded-full flex items-center justify-center shrink-0 mt-0.5 ${
                            plan.highlighted
                              ? 'bg-red-600/20 text-red-400 border border-red-500/30'
                              : 'bg-neutral-800 text-neutral-400'
                          }`}
                        >
                          <Check className="w-3.5 h-3.5" />
                        </div>
                        <span>{feature}</span>
                      </li>
                    ))}
                  </ul>
                </div>

                {/* Join Now WhatsApp Button */}
                <div className="pt-4 border-t border-neutral-800/80">
                  <a
                    href={joinWhatsAppUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className={`w-full flex items-center justify-center gap-2 py-3.5 px-6 rounded-xl font-heading text-base font-bold uppercase tracking-wider transition-all duration-200 shadow-md ${
                      plan.highlighted
                        ? 'bg-red-600 hover:bg-red-500 text-white shadow-red-600/30 hover:shadow-red-600/50'
                        : 'bg-neutral-800 hover:bg-neutral-700 text-white border border-neutral-700'
                    }`}
                  >
                    <MessageSquare className="w-4 h-4 fill-white/20" />
                    <span>Join Now</span>
                  </a>
                </div>
              </div>
            );
          })}
        </div>

        {/* Mandatory line & Personal Training Feature Box */}
        <div className="mt-12 p-6 sm:p-8 rounded-2xl bg-neutral-900/70 border border-neutral-800 max-w-4xl mx-auto flex flex-col md:flex-row items-center justify-between gap-6">
          <div className="flex items-center gap-4">
            <div className="w-12 h-12 rounded-xl bg-red-600/20 border border-red-500/30 text-red-400 flex items-center justify-center shrink-0">
              <UserCheck className="w-6 h-6" />
            </div>
            <div>
              <p className="font-heading text-xl sm:text-2xl font-black text-white uppercase tracking-wide">
                Personal training available.
              </p>
              <p className="text-sm text-neutral-300">
                1-on-1 certified mentorship with customized diet charts, form correction, and weekly fat-loss/muscle check-ins.
              </p>
            </div>
          </div>

          <a
            href={buildWhatsAppLink(
              config.whatsappRaw,
              `Hi ${config.name} ${config.edition}! I would like to inquire about Personal Training (PT) packages in ${config.city}.`
            )}
            target="_blank"
            rel="noopener noreferrer"
            className="whitespace-nowrap px-6 py-3 text-xs sm:text-sm font-bold uppercase tracking-wider font-heading bg-neutral-800 hover:bg-neutral-700 hover:text-white border border-neutral-700 text-neutral-200 rounded-lg transition-all"
          >
            Inquire About PT
          </a>
        </div>
      </div>
    </section>
  );
}
