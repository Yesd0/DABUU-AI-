import { Phone, MessageSquare, Flame, ShieldCheck, Dumbbell, Award } from 'lucide-react';
import { GymConfig, buildWhatsAppLink } from '../data/gymData';
import { GymImage } from './GymImage';

interface HeroSectionProps {
  config: GymConfig;
}

export function HeroSection({ config }: HeroSectionProps) {
  const trialWhatsAppUrl = buildWhatsAppLink(
    config.whatsappRaw,
    `Hi ${config.name} ${config.edition}! I want to book a free trial workout session at ${config.city}. Please let me know available slots.`
  );

  return (
    <section id="hero" className="relative overflow-hidden pt-12 pb-20 md:pt-20 md:pb-28">
      {/* Background ambient lighting effects */}
      <div className="absolute top-1/4 -left-32 w-96 h-96 bg-red-600/10 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute bottom-10 right-0 w-80 h-80 bg-red-700/10 rounded-full blur-3xl pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-8 items-center">
          {/* Column 1: Copy & CTAs */}
          <div className="lg:col-span-7 flex flex-col justify-center space-y-8">
            {/* Athletic kicker */}
            <div className="inline-flex items-center gap-2 self-start text-xs font-bold tracking-widest uppercase font-heading text-red-500 border border-red-500/30 px-3 py-1.5 rounded bg-red-950/30">
              <Flame className="w-3.5 h-3.5 fill-red-500" />
              <span>{config.city.toUpperCase()}&apos;S PREMIER FITNESS DESTINATION</span>
            </div>

            {/* Headline */}
            <div className="space-y-4">
              <h1 className="font-heading text-4xl sm:text-5xl md:text-6xl lg:text-7xl font-black tracking-tight text-white uppercase leading-[0.95] text-balance">
                Transform Your Body at{' '}
                <span className="text-red-500 underline decoration-red-600/40 decoration-wavy decoration-2">
                  RJ Fitness Hub {config.edition}
                </span>
              </h1>
              <p className="text-lg sm:text-xl text-neutral-300 font-medium max-w-2xl leading-relaxed">
                Expert trainers. Modern equipment. {config.city}&apos;s newest gym.
              </p>
            </div>

            {/* Motivating bullet points / micro-proof */}
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-4 pt-1">
              <div className="flex items-center gap-2.5 text-xs sm:text-sm text-neutral-300">
                <div className="w-5 h-5 rounded bg-red-600/20 text-red-400 flex items-center justify-center shrink-0">
                  <Dumbbell className="w-3 h-3" />
                </div>
                <span>Heavy free weights</span>
              </div>
              <div className="flex items-center gap-2.5 text-xs sm:text-sm text-neutral-300">
                <div className="w-5 h-5 rounded bg-red-600/20 text-red-400 flex items-center justify-center shrink-0">
                  <Award className="w-3 h-3" />
                </div>
                <span>Certified mentors</span>
              </div>
              <div className="flex items-center gap-2.5 text-xs sm:text-sm text-neutral-300 col-span-2 sm:col-span-1">
                <div className="w-5 h-5 rounded bg-red-600/20 text-red-400 flex items-center justify-center shrink-0">
                  <ShieldCheck className="w-3 h-3" />
                </div>
                <span>Clean & energized</span>
              </div>
            </div>

            {/* Two Action Buttons */}
            <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-4 pt-2">
              <a
                href={trialWhatsAppUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center justify-center gap-3 px-8 py-4 text-base font-bold uppercase tracking-wider font-heading bg-red-600 hover:bg-red-500 active:scale-95 text-white rounded transition-all shadow-lg shadow-red-600/30 glow-red whitespace-nowrap text-center"
              >
                <MessageSquare className="w-5 h-5 fill-white/20" />
                <span>Book Free Trial</span>
              </a>

              <a
                href={`tel:${config.phoneRaw}`}
                className="flex items-center justify-center gap-3 px-8 py-4 text-base font-bold uppercase tracking-wider font-heading bg-neutral-900 hover:bg-neutral-800 hover:text-white border border-neutral-700 active:scale-95 text-neutral-200 rounded transition-all whitespace-nowrap text-center"
              >
                <Phone className="w-5 h-5 text-red-500" />
                <span>Call Now</span>
              </a>
            </div>

            {/* Note under buttons */}
            <div className="text-xs text-neutral-400 flex items-center gap-2 pt-1">
              <span className="w-2 h-2 rounded-full bg-red-500 inline-block" />
              <span>Free 1-Day Trial Pass includes gym floor tour and body assessment.</span>
            </div>
          </div>

          {/* Column 2: Big Gym Photo / Visual Anchor */}
          <div className="lg:col-span-5 relative">
            <div className="relative rounded-2xl overflow-hidden border border-neutral-800 shadow-2xl bg-neutral-900">
              <GymImage
                src="https://images.unsplash.com/photo-1534438327276-14e5300c3a48?auto=format&fit=crop&w=1400&q=85"
                alt="RJ Fitness Hub 2.0 Gym Floor and Training Area"
                className="w-full h-[400px] sm:h-[480px] lg:h-[540px] object-cover"
                category="Main Strength Arena"
              />

              {/* Scrim Overlay */}
              <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-black/25 to-transparent pointer-events-none" />

              {/* In-image badge */}
              <div className="absolute bottom-6 left-6 right-6 p-4 rounded-xl bg-neutral-950/85 backdrop-blur-md border border-neutral-800 flex items-center justify-between">
                <div>
                  <p className="text-xs font-bold text-red-400 uppercase tracking-widest font-heading">
                    {config.city} Flagship Facility
                  </p>
                  <p className="text-sm font-semibold text-white">Top tier strength & cardio gear</p>
                </div>
                <div className="text-right">
                  <span className="text-xs text-neutral-400 block">Open 7 Days</span>
                  <span className="text-sm font-bold text-white font-mono">6 AM - 10 PM</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
