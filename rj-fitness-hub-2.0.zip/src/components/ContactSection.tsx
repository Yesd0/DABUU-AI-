import { useState } from 'react';
import {
  MapPin,
  Clock,
  MessageSquare,
  Instagram,
  Phone,
  Navigation,
  Send,
  CheckCircle,
} from 'lucide-react';
import { GymConfig, buildWhatsAppLink } from '../data/gymData';

interface ContactSectionProps {
  config: GymConfig;
}

export function ContactSection({ config }: ContactSectionProps) {
  const [inquiryName, setInquiryName] = useState('');
  const [inquiryTopic, setInquiryTopic] = useState('Free Trial Session');
  const [inquiryPhone, setInquiryPhone] = useState('');
  const [formSent, setFormSent] = useState(false);

  const handleInquirySubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const msg = `Hi ${config.name} ${config.edition}! My name is ${inquiryName || 'Fitness Enthusiast'}${
      inquiryPhone ? ` (Phone: ${inquiryPhone})` : ''
    }. I am reaching out regarding: ${inquiryTopic} at your ${config.city} gym.`;

    const url = buildWhatsAppLink(config.whatsappRaw, msg);
    setFormSent(true);
    window.open(url, '_blank');
    setTimeout(() => setFormSent(false), 5000);
  };

  const directWhatsAppUrl = buildWhatsAppLink(
    config.whatsappRaw,
    `Hi ${config.name} ${config.edition}! I have a quick question about the gym in ${config.city}.`
  );

  return (
    <section id="contact" className="py-20 bg-[#090b0f] border-t border-neutral-800/80 relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-16 space-y-4">
          <span className="text-xs font-bold tracking-widest uppercase font-heading text-red-500 border border-red-500/20 px-3 py-1 rounded bg-red-950/20">
            CONNECT & VISIT
          </span>
          <h2 className="font-heading text-3xl sm:text-4xl md:text-5xl font-black uppercase text-white tracking-tight">
            Contact & Timings
          </h2>
          <p className="text-base sm:text-lg text-neutral-300">
            Visit our hub in {config.city}. Join the strongest community today.
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          {/* Left Column: Address, Timings, WhatsApp & Instagram */}
          <div className="lg:col-span-6 space-y-6">
            {/* Address Card */}
            <div className="p-6 rounded-2xl bg-neutral-900 border border-neutral-800 flex items-start gap-4">
              <div className="w-12 h-12 rounded-xl bg-red-600/20 border border-red-500/30 text-red-400 flex items-center justify-center shrink-0 mt-1">
                <MapPin className="w-6 h-6" />
              </div>
              <div className="space-y-1">
                <h3 className="font-heading text-lg font-bold text-white uppercase tracking-wide">
                  Gym Address
                </h3>
                <p className="text-sm text-neutral-300 leading-relaxed font-medium">
                  {config.address}
                </p>
                <div className="pt-2">
                  <a
                    href={`https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(
                      `${config.name} ${config.address}`
                    )}`}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-flex items-center gap-1.5 text-xs font-bold text-red-400 hover:text-red-300 uppercase tracking-wider font-heading"
                  >
                    <Navigation className="w-3.5 h-3.5" />
                    <span>Get Directions on Google Maps</span>
                  </a>
                </div>
              </div>
            </div>

            {/* Timings Card */}
            <div className="p-6 rounded-2xl bg-neutral-900 border border-neutral-800 flex items-start gap-4">
              <div className="w-12 h-12 rounded-xl bg-red-600/20 border border-red-500/30 text-red-400 flex items-center justify-center shrink-0 mt-1">
                <Clock className="w-6 h-6" />
              </div>
              <div className="space-y-2 flex-1">
                <h3 className="font-heading text-lg font-bold text-white uppercase tracking-wide">
                  Training Hours
                </h3>
                <div className="space-y-1 text-sm">
                  <div className="flex items-center justify-between text-neutral-300">
                    <span className="font-medium">Monday – Saturday:</span>
                    <span className="font-mono font-semibold text-white">6:00 AM – 10:00 PM</span>
                  </div>
                  <div className="flex items-center justify-between text-neutral-300">
                    <span className="font-medium">Sunday:</span>
                    <span className="font-mono font-semibold text-white">7:00 AM – 1:00 PM</span>
                  </div>
                </div>
                <p className="text-xs text-neutral-400 pt-1">
                  Peak hours: 7:00 AM - 9:30 AM & 6:30 PM - 9:00 PM.
                </p>
              </div>
            </div>

            {/* WhatsApp & Call Channels */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              {/* WhatsApp Card */}
              <div className="p-5 rounded-2xl bg-neutral-900 border border-neutral-800 flex flex-col justify-between">
                <div className="flex items-center gap-3 mb-3">
                  <div className="w-9 h-9 rounded-lg bg-emerald-600/20 border border-emerald-500/30 text-emerald-400 flex items-center justify-center">
                    <MessageSquare className="w-4 h-4 fill-emerald-500/20" />
                  </div>
                  <div>
                    <span className="text-xs text-neutral-400 uppercase font-mono">WhatsApp</span>
                    <h4 className="text-sm font-bold text-white font-mono">{config.whatsapp}</h4>
                  </div>
                </div>
                <a
                  href={directWhatsAppUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="w-full flex items-center justify-center gap-2 py-2.5 px-4 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white font-heading text-xs font-bold uppercase tracking-wider transition-colors"
                >
                  <MessageSquare className="w-3.5 h-3.5" />
                  <span>Chat on WhatsApp</span>
                </a>
              </div>

              {/* Instagram Card */}
              <div className="p-5 rounded-2xl bg-neutral-900 border border-neutral-800 flex flex-col justify-between">
                <div className="flex items-center gap-3 mb-3">
                  <div className="w-9 h-9 rounded-lg bg-red-600/20 border border-red-500/30 text-red-400 flex items-center justify-center">
                    <Instagram className="w-4 h-4" />
                  </div>
                  <div>
                    <span className="text-xs text-neutral-400 uppercase font-mono">Instagram</span>
                    <h4 className="text-sm font-bold text-white">{config.instagramHandle}</h4>
                  </div>
                </div>
                <a
                  href={config.instagramUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="w-full flex items-center justify-center gap-2 py-2.5 px-4 rounded-lg bg-neutral-800 hover:bg-neutral-700 text-white font-heading text-xs font-bold uppercase tracking-wider border border-neutral-700 transition-colors"
                >
                  <Instagram className="w-3.5 h-3.5 text-red-400" />
                  <span>Follow @rj_fitness_2.0</span>
                </a>
              </div>
            </div>

            {/* Quick WhatsApp Inquiry Form */}
            <div className="p-6 rounded-2xl bg-neutral-900/60 border border-neutral-800">
              <h4 className="font-heading text-base font-bold text-white uppercase tracking-wide mb-3 flex items-center gap-2">
                <span>Quick WhatsApp Inquiry</span>
                <span className="text-xs font-normal text-neutral-400 font-sans">(Direct to Gym Desk)</span>
              </h4>
              <form onSubmit={handleInquirySubmit} className="space-y-3">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <input
                    type="text"
                    value={inquiryName}
                    onChange={(e) => setInquiryName(e.target.value)}
                    placeholder="Your Name (e.g., Rohit Sharma)"
                    className="w-full px-3.5 py-2.5 rounded-lg bg-neutral-950 border border-neutral-800 text-white placeholder-neutral-500 text-xs focus:outline-none focus:border-red-500"
                  />
                  <input
                    type="tel"
                    value={inquiryPhone}
                    onChange={(e) => setInquiryPhone(e.target.value)}
                    placeholder="Phone Number (Optional)"
                    className="w-full px-3.5 py-2.5 rounded-lg bg-neutral-950 border border-neutral-800 text-white placeholder-neutral-500 text-xs focus:outline-none focus:border-red-500"
                  />
                </div>
                <select
                  value={inquiryTopic}
                  onChange={(e) => setInquiryTopic(e.target.value)}
                  className="w-full px-3.5 py-2.5 rounded-lg bg-neutral-950 border border-neutral-800 text-neutral-200 text-xs focus:outline-none focus:border-red-500"
                >
                  <option value="Free Trial Session">Book 1-Day Free Trial</option>
                  <option value="Monthly Plan Inquiry">Monthly Plan (₹1,499)</option>
                  <option value="Quarterly Plan Inquiry">Quarterly Plan (₹3,799)</option>
                  <option value="Yearly Plan Inquiry">Yearly Plan (₹11,999)</option>
                  <option value="Personal Training (PT) Rates">Personal Training Packages</option>
                  <option value="Diet & Nutrition Consult">Diet Consultation</option>
                </select>
                <button
                  type="submit"
                  className="w-full py-3 px-4 rounded-lg bg-red-600 hover:bg-red-500 active:scale-95 text-white font-heading font-bold text-xs uppercase tracking-wider flex items-center justify-center gap-2 transition-all shadow-md shadow-red-600/30"
                >
                  {formSent ? (
                    <>
                      <CheckCircle className="w-4 h-4 text-white" />
                      <span>Opening WhatsApp...</span>
                    </>
                  ) : (
                    <>
                      <Send className="w-4 h-4" />
                      <span>Send Instant Inquiry via WhatsApp</span>
                    </>
                  )}
                </button>
              </form>
            </div>
          </div>

          {/* Right Column: Google Maps Embed & Location Visual */}
          <div className="lg:col-span-6 space-y-4">
            <div className="rounded-2xl overflow-hidden border border-neutral-800 bg-neutral-900 shadow-2xl relative">
              <div className="p-4 bg-neutral-950/90 border-b border-neutral-800 flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <MapPin className="w-4 h-4 text-red-500" />
                  <span className="font-heading text-sm font-bold uppercase text-white tracking-wide">
                    Live Location Map
                  </span>
                </div>
                <span className="text-xs text-neutral-400 font-mono">
                  {config.city}, India
                </span>
              </div>

              {/* Google Maps Embed iframe */}
              <div className="relative w-full h-[360px] sm:h-[440px] bg-neutral-950">
                <iframe
                  title="RJ Fitness Hub 2.0 Location Map"
                  src={`https://maps.google.com/maps?q=${encodeURIComponent(
                    `${config.name} ${config.address}`
                  )}&t=&z=15&ie=UTF8&iwloc=&output=embed`}
                  className="w-full h-full border-0 filter contrast-125 brightness-90 grayscale-[25%]"
                  loading="lazy"
                  referrerPolicy="no-referrer"
                  allowFullScreen
                />
              </div>

              <div className="p-4 bg-neutral-950 border-t border-neutral-800 flex flex-col sm:flex-row items-center justify-between gap-3 text-xs">
                <div className="text-neutral-400 text-center sm:text-left">
                  <span>Landmark: Near C21 Mall / AB Road · Dedicated gym parking available</span>
                </div>
                <a
                  href={`https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(
                    `${config.name} ${config.address}`
                  )}`}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="whitespace-nowrap px-3 py-1.5 rounded bg-neutral-800 hover:bg-neutral-700 text-white font-semibold flex items-center gap-1.5 transition-colors"
                >
                  <Navigation className="w-3.5 h-3.5 text-red-400" />
                  <span>Open Full Map</span>
                </a>
              </div>
            </div>

            {/* Direct Call Quick Bar */}
            <div className="p-4 rounded-xl bg-neutral-900 border border-neutral-800 flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="w-8 h-8 rounded-full bg-red-600/20 text-red-400 flex items-center justify-center">
                  <Phone className="w-4 h-4" />
                </div>
                <div>
                  <span className="text-xs text-neutral-400 block">Direct Front Desk Call</span>
                  <span className="text-sm font-bold text-white font-mono">{config.phone}</span>
                </div>
              </div>
              <a
                href={`tel:${config.phoneRaw}`}
                className="px-4 py-2 rounded-lg bg-neutral-800 hover:bg-neutral-700 text-xs font-bold uppercase font-heading text-white border border-neutral-700"
              >
                Call Front Desk
              </a>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
