/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState } from 'react';
import { initialGymConfig, GymConfig } from './data/gymData';
import { Navbar } from './components/Navbar';
import { HeroSection } from './components/HeroSection';
import { PlansSection } from './components/PlansSection';
import { FacilitiesSection } from './components/FacilitiesSection';
import { ContactSection } from './components/ContactSection';
import { Footer } from './components/Footer';
import { FloatingWhatsApp } from './components/FloatingWhatsApp';
import { CustomizerModal } from './components/CustomizerModal';

export default function App() {
  const [config, setConfig] = useState<GymConfig>(initialGymConfig);
  const [isCustomizerOpen, setIsCustomizerOpen] = useState(false);

  return (
    <div className="min-h-screen bg-[#08090c] text-neutral-100 flex flex-col font-sans selection:bg-red-600 selection:text-white">
      {/* Top Bar Navigation */}
      <Navbar config={config} onOpenCustomizer={() => setIsCustomizerOpen(true)} />

      {/* Main Content Area */}
      <main className="flex-1">
        {/* Section 1: Hero */}
        <HeroSection config={config} />

        {/* Section 2: Plans & Prices */}
        <PlansSection config={config} />

        {/* Section 3: Facilities & Gallery */}
        <FacilitiesSection config={config} />

        {/* Section 4: Contact & Location */}
        <ContactSection config={config} />
      </main>

      {/* Footer */}
      <Footer config={config} onOpenCustomizer={() => setIsCustomizerOpen(true)} />

      {/* Floating WhatsApp CTA on every screen */}
      <FloatingWhatsApp config={config} />

      {/* Modal to customize city, prices, phone, timings, address */}
      <CustomizerModal
        isOpen={isCustomizerOpen}
        onClose={() => setIsCustomizerOpen(false)}
        config={config}
        onSave={(newConfig) => setConfig(newConfig)}
      />
    </div>
  );
}
